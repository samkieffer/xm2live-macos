#!/usr/bin/env python3
"""
Lecteur d'enveloppes volume pour fichiers XM (séparé du parser principal)
Basé sur test_envelope_parser.py qui fonctionne
"""

import struct


def read_xm_envelopes(xm_path):
    """Lit les enveloppes volume des instruments XM

    Returns:
        dict {instrument_num: envelope_info}
        où envelope_info = {'enabled', 'sustain_enabled', 'num_points', 'sustain_point', 'points'}
    """

    envelopes = {}

    try:
        with open(xm_path, 'rb') as f:
            # Skip header principal (60 bytes)
            f.read(60)

            # Lire les métadonnées
            header_size = struct.unpack('<I', f.read(4))[0]
            song_length = struct.unpack('<H', f.read(2))[0]
            f.read(2)  # restart pos
            num_channels = struct.unpack('<H', f.read(2))[0]
            num_patterns = struct.unpack('<H', f.read(2))[0]
            num_instruments = struct.unpack('<H', f.read(2))[0]
            f.read(2 + 2 + 2 + 256)  # flags, tempo, bpm, pattern order

            # Skip patterns
            for i in range(num_patterns):
                pattern_header_len = struct.unpack('<I', f.read(4))[0]
                f.read(1)  # packing type
                num_rows = struct.unpack('<H', f.read(2))[0]
                packed_size = struct.unpack('<H', f.read(2))[0]

                remaining_header = pattern_header_len - 9
                if remaining_header > 0:
                    f.read(remaining_header)
                if packed_size > 0:
                    f.read(packed_size)

            # Lire les instruments SEULEMENT pour les enveloppes
            for inst_num in range(num_instruments):
                try:
                    inst_header_size = struct.unpack('<I', f.read(4))[0]

                    if inst_header_size < 29:
                        continue

                    inst_name = f.read(22).decode('ascii', errors='ignore').strip('\x00')
                    inst_type = struct.unpack('<B', f.read(1))[0]
                    num_samples = struct.unpack('<H', f.read(2))[0]

                    envelope_info = None

                    if num_samples > 0 and num_samples < 256 and inst_header_size >= 241:
                        sample_header_size = struct.unpack('<I', f.read(4))[0]

                        # Lire les données d'enveloppe
                        note_map = f.read(96)  # Note-to-sample mapping

                        # Volume envelope points (12 points × 4 bytes)
                        vol_env_points = []
                        for i in range(12):
                            time = struct.unpack('<H', f.read(2))[0]
                            value = struct.unpack('<H', f.read(2))[0]
                            vol_env_points.append((time, value))

                        # Panning envelope - skip
                        f.read(48)

                        # Envelope parameters
                        num_vol_points = struct.unpack('<B', f.read(1))[0]
                        num_pan_points = struct.unpack('<B', f.read(1))[0]
                        vol_sustain_point = struct.unpack('<B', f.read(1))[0]
                        vol_loop_start = struct.unpack('<B', f.read(1))[0]
                        vol_loop_end = struct.unpack('<B', f.read(1))[0]
                        pan_sustain_point = struct.unpack('<B', f.read(1))[0]
                        pan_loop_start = struct.unpack('<B', f.read(1))[0]
                        pan_loop_end = struct.unpack('<B', f.read(1))[0]
                        vol_type = struct.unpack('<B', f.read(1))[0]
                        pan_type = struct.unpack('<B', f.read(1))[0]

                        # Vibrato + fadeout
                        f.read(6)

                        # Reserved
                        f.read(2)

                        # Skip remaining instrument header
                        bytes_read = 29 + 4 + 96 + 48 + 48 + 14 + 2
                        remaining = inst_header_size - bytes_read
                        if remaining > 0:
                            f.read(remaining)

                        # Créer envelope_info
                        vol_enabled = vol_type & 0x01
                        vol_sustain_enabled = vol_type & 0x02

                        envelope_info = {
                            'enabled': bool(vol_enabled),
                            'sustain_enabled': bool(vol_sustain_enabled),
                            'num_points': num_vol_points,
                            'sustain_point': vol_sustain_point,
                            'points': vol_env_points[:num_vol_points] if vol_enabled else []
                        }

                        # Skip sample headers (40 bytes each)
                        for j in range(num_samples):
                            f.read(40)

                        # Skip sample data
                        # On doit revenir en arrière pour lire les tailles
                        for j in range(num_samples):
                            current_pos = f.tell()
                            # Retourner au header du sample pour lire sa taille
                            f.seek(current_pos - (num_samples - j) * 40)
                            sample_len = struct.unpack('<I', f.read(4))[0]
                            # Revenir à la position après tous les headers
                            f.seek(current_pos - (num_samples - j - 1) * 40)

                            # Avancer au-delà des données du sample
                            if sample_len > 0 and sample_len < 10000000:
                                f.read(sample_len)

                    else:
                        # Pas de samples ou header trop court, skip tout
                        remaining = inst_header_size - 29
                        if remaining > 0:
                            f.read(remaining)

                        envelope_info = {
                            'enabled': False,
                            'sustain_enabled': False,
                            'num_points': 0,
                            'sustain_point': 0,
                            'points': []
                        }

                    if envelope_info:
                        envelopes[inst_num + 1] = envelope_info

                except Exception as e:
                    # En cas d'erreur sur un instrument, continuer
                    pass

    except Exception as e:
        print(f"    ⚠️  Erreur lecture enveloppes: {e}")

    return envelopes
